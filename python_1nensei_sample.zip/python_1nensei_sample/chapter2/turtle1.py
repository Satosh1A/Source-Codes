from turtle import *
shape("turtle")
forward(100)
done()
	