for i in range(10):
    print(5,"x",i,"=",5*i)
