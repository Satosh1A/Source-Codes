scorelist = [64, 100, 78, 80, 72]
total = 0
for i in scorelist:
    total = total + i
print(total)
