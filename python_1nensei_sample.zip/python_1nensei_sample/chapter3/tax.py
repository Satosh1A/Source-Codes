def postTaxPrice(price):
    ans = price * 1.08
    return ans
