from turtle import *
shape("turtle")
col = ["red","blue","green","brown","black"]
for i in range(5):
    color(col[i])
    forward(200)
    left(144)
done()