import random
kuji = ["大吉", "中吉", "小吉", "凶", "半吉", "末吉", "大凶", "大大吉"]
print(random.choice(kuji))