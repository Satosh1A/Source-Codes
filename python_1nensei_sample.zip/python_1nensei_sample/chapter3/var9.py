b = "こんにちは"
if b.isdigit():
    print(int(b)+23)
else:
    print("数値じゃないよ")