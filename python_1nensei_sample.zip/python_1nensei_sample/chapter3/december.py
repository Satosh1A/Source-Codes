import calendar 
print(calendar.month(2017,12))