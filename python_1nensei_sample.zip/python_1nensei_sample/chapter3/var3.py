i = 100
f = 12.3
w = "hello"
b = True
print(i, f, w, b)